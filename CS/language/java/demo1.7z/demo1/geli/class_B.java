package demo1.geli;


public class class_B implements Interface2  {
	public void method1(){
        System.out.println("1");
    }
	public void method4(){
        System.out.println("4");
    }
	public void method5(){
        System.out.println("5");
    }
}
