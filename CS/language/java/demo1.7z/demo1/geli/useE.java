package demo1.geli;

public class useE{
    public void depend1(Interface1 i1){
        i1.method1();
    }
    public void depend2(Interface1 i1){
        i1.method2();
    }
    public void depend3(Interface1 i1){
        i1.method3();
    }
}

