package demo1.geli;



public interface Interface1 {
    
    public void method1();
	public void method2();
	public void method3();
}