package demo1.geli;

public class useF{
    public void depend1(Interface2 i2){
        i2.method1();
    }
    public void depend4(Interface2 i2){
        i2.method4();
    }
    public void depend5(Interface2 i2){
        i2.method5();
    }
}
