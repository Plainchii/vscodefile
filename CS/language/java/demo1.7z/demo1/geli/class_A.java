package demo1.geli;



public class class_A implements Interface1  {
	
    public void method1(){
        System.out.println("1");
    }
	public void method2(){
        System.out.println("2");
    }
	public void method3(){
        System.out.println("3");
    }
}
