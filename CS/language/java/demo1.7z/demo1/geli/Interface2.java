package demo1.geli;

public interface Interface2 {
    public void method1();
	public void method4();
	public void method5();
}
